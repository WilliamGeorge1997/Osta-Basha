<?php

return [
    'name' => 'ShopOwner',
];
