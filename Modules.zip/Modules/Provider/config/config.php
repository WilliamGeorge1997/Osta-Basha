<?php

return [
    'name' => 'Provider',
];
