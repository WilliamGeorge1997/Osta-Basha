<?php

return [
    'name' => 'Common',
];
