<?php

namespace Modules\ShopOwner\Database\Seeders;

use Illuminate\Database\Seeder;

class ShopOwnerDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
