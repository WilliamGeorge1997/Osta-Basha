<?php

namespace Modules\Provider\Database\Seeders;

use Illuminate\Database\Seeder;

class ProviderDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
