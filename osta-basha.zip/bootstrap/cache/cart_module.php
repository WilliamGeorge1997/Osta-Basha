<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Cart\\App\\Providers\\CartServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Cart\\App\\Providers\\CartServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);