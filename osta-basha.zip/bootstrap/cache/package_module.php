<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Package\\App\\Providers\\PackageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Package\\App\\Providers\\PackageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);