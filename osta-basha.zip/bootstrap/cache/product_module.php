<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Product\\App\\Providers\\ProductServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Product\\App\\Providers\\ProductServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);