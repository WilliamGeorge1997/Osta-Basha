<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Driver\\App\\Providers\\DriverServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Driver\\App\\Providers\\DriverServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);