<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Service\\App\\Providers\\ServiceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Service\\App\\Providers\\ServiceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);