<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ShopOwner\\App\\Providers\\ShopOwnerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ShopOwner\\App\\Providers\\ShopOwnerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);