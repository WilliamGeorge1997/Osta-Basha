<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Client\\App\\Providers\\ClientServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Client\\App\\Providers\\ClientServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);