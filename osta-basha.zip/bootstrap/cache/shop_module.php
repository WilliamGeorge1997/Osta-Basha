<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Shop\\App\\Providers\\ShopServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Shop\\App\\Providers\\ShopServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);